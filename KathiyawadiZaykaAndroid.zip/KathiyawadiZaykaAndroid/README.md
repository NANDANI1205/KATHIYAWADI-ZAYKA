# Kathiyawadi Zayka — Android App

This project wraps the current Kathiyawadi Zayka Daily Diary & Expense Manager in a native Android WebView shell.

## Included
- Daily sales and expenses
- Cash / UPI / Card / Zomato / Swiggy / Paytm entries
- Weekly and monthly history
- Salary & Staff with advance and absence deductions
- Monthly printable report / Save as PDF
- LocalStorage data remains on the phone
- Portrait mobile layout

## Build
1. Install Android Studio.
2. Open this folder: `KathiyawadiZaykaAndroid`.
3. Let Gradle sync and install the required Android SDK when prompted.
4. Choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated APK on an Android phone.

No server is required for the app itself; its data is stored locally on the device.
